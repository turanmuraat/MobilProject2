package com.example.shoppingapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.MyViewHolder> {
    static final String TAG = "ProductAdapter";
    Context context;
    List<Product> productList;

    public ProductAdapter(Context context, List<Product> productList){
        this.context = context;
        this.productList = productList;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView productName;
        TextView productPrice;
        TextView productNumber;
        Button btn_delete;

        public MyViewHolder(View view){
            super(view);
            productName = view.findViewById(R.id.productName);
            productPrice = view.findViewById(R.id.productPrice);
            productNumber = view.findViewById(R.id.productNumber);
            btn_delete = view.findViewById(R.id.btn_delete);
        }

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.product_card,parent,false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        if(getItemCount() == 0)
            Toast.makeText(context,"There is no any product!",Toast.LENGTH_SHORT).show();
        holder.productName.setText(productList.get(position).getProductId());
        holder.btn_delete.setOnClickListener((v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setMessage("Product will delete!")
                    .setCancelable(true)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Product.deleteSelectedProductList(productList.get(position).getProductId());
                            Toast.makeText(context,"Product is deleted!",Toast.LENGTH_SHORT).show();
                            notifyItemRemoved(position);
                            notifyItemRangeChanged(position, getItemCount());
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
            }));
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }


}
