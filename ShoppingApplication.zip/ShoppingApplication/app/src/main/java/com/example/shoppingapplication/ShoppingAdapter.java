package com.example.shoppingapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ShoppingAdapter extends RecyclerView.Adapter<ShoppingAdapter.MyViewHolder> {
    static final String TAG = "ShoppingAdapter";
    Context context;
    List<Shopping> shoppingList;

    public ShoppingAdapter(Context context, List<Shopping> shoppingList){
        this.context = context;
        this.shoppingList = shoppingList;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView shoppingName;
        EditText newListName;
        LinearLayout linearLayout;
        Button btn_delete;
        Button btn_update;
        Button btn_open;
        Button btn_add;

        public MyViewHolder(View view){
            super(view);
            shoppingName = view.findViewById(R.id.shoppingName);
            newListName = view.findViewById(R.id.newListName);
            btn_delete = view.findViewById(R.id.btn_delete);
            btn_update = view.findViewById(R.id.btn_update);
            btn_open = view.findViewById(R.id.btn_open);
            btn_add = view.findViewById(R.id.btn_add);
        }

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.shopping_card,parent,false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        if(getItemCount() == 0)
            Toast.makeText(context,"There is no any record!",Toast.LENGTH_SHORT).show();
        holder.btn_delete.setOnClickListener((v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setMessage("Shopping Record will delete!")
                    .setCancelable(true)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Shopping.deleteSelectedShoppingList(shoppingList.get(position).getShoppingId());
                            Toast.makeText(context,"Shopping Record is deleted!",Toast.LENGTH_SHORT).show();
                            notifyItemRemoved(position);
                            notifyItemRangeChanged(position, getItemCount());
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
            }));
        holder.btn_update.setOnClickListener((v -> {
            /*Intent intent = new Intent(context,UpdateShoppingActivity.class);
            intent.putExtra("shoppingId",shoppingList.get(position).getShoppingId());
            //intent.putExtra("product",shoppingList.get(position).getProducts());
            context.startActivity(intent);*/

        }));
        holder.btn_open.setOnClickListener((v -> {
            Intent intent = new Intent(v.getContext(), ShoppingListDetailActivity.class);
            intent.putExtra("shoppingId",shoppingList.get(position).getShoppingId());
            context.startActivity(intent);
        }));

        holder.btn_add.setOnClickListener((v -> {
            String shoppingName = holder.newListName.getText().toString();
            List<Product> product = new ArrayList<>();
            Shopping shopping = new Shopping(shoppingName,product);
            Shopping.addShoppingToFirebase(shopping);
        }));
    }

    @Override
    public int getItemCount() {
        return shoppingList.size();
    }


}
