package com.example.shoppingapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static com.example.shoppingapplication.Product.addProductToFirebase;
import static com.example.shoppingapplication.Shopping.addShoppingToFirebase;

public class MainActivity extends AppCompatActivity {

    static final String TAG = "MainActivity";
    androidx.recyclerview.widget.RecyclerView.LayoutManager layoutManager;
    List<Shopping> shoppingList;
    androidx.recyclerview.widget.RecyclerView recyclerView;
    ShoppingAdapter adp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        defineVariables();

    }

    public void defineVariables(){
        recyclerView = (androidx.recyclerview.widget.RecyclerView) findViewById(R.id.recyclerview);
        layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        shoppingList = new ArrayList<>();
        shoppingList = Shopping.getShoppingList();
        adp = new ShoppingAdapter(this,shoppingList);
        recyclerView.setAdapter(adp);
    }
}
