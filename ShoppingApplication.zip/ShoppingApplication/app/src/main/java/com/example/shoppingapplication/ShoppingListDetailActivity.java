package com.example.shoppingapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ShoppingListDetailActivity extends AppCompatActivity {
    static final String TAG = "ShoppingListDetailActivity";
    androidx.recyclerview.widget.RecyclerView.LayoutManager layoutManager;
    List<Product> productList;
    androidx.recyclerview.widget.RecyclerView recyclerView;
    ProductAdapter adp;
    String currentShoppingId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list_detail);
        defineVariables();

    }

    public void defineVariables(){
        recyclerView = (androidx.recyclerview.widget.RecyclerView) findViewById(R.id.recyclerview);
        layoutManager = new LinearLayoutManager(getApplicationContext());
        currentShoppingId = getIntent().getStringExtra("shoppingId");
        recyclerView.setLayoutManager(layoutManager);
        productList = new ArrayList<>();
        productList = Shopping.getProductListByShoppingId(currentShoppingId);
        adp = new ProductAdapter(this,productList);
        recyclerView.setAdapter(adp);
    }


}