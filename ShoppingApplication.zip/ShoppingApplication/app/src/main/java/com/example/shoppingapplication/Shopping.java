package com.example.shoppingapplication;

import android.util.Log;

import com.google.android.gms.common.server.converter.StringToIntConverter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Shopping {
    static final String TAG = "Shopping";
    private String shoppingId;
    private String shoppingName;
    private List<Product> products;
    private Product product;

    static DatabaseReference mDatabase;
    static DatabaseReference shoppingCloudEndPoint;

    public Shopping(){

    }

    public Shopping(String shoppingName, List<Product> products) {
        this.shoppingName = shoppingName;
        this.products = products;
    }

    public List<Product> getProducts() {
        return products;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.products.add(product);
    }

    public String getShoppingId() { return shoppingId; }

    public void setShoppingId(String shoppingId) { this.shoppingId = shoppingId; }

    public String getShoppingName() { return shoppingName; }

    public void setShoppingName(String shoppingId) { this.shoppingName = shoppingName; }

    public static List<Shopping> getShoppingList(){
        mDatabase =  FirebaseDatabase.getInstance().getReference();
        shoppingCloudEndPoint = mDatabase.child("Shopping");
        List<Shopping> mEntries = new ArrayList<>();
        shoppingCloudEndPoint.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot noteSnapshot: dataSnapshot.getChildren()){
                    Shopping note = noteSnapshot.getValue(Shopping.class);
                    note.shoppingName = (String) noteSnapshot.child("shoppingName").getValue();
                    String temp = note.toString();
                    Log.d("note: ", temp + "\n"); // can log all
                    mEntries.add(note);
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.d(TAG, databaseError.getMessage());
            }
        });
        return mEntries;
    }

    public static List<Product> getProductListByShoppingId(String shoppingId){
        mDatabase =  FirebaseDatabase.getInstance().getReference();
        shoppingCloudEndPoint = mDatabase.child("Shopping");
        List<Product> mEntries = new ArrayList<>();
        Query query = shoppingCloudEndPoint.orderByChild("shoppingId").equalTo(shoppingId);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot noteSnapshot: dataSnapshot.getChildren()){
                    Shopping note = noteSnapshot.getValue(Shopping.class);

                    ArrayList<HashMap> products =  (ArrayList) noteSnapshot.child("products").getValue();
                    for(HashMap<String,String> item: products){
                        Log.d("ITEM : ", item.toString());
                        Product pro = new Product();
                        pro.setProductId(item.get("productId"));
                        pro.setProductName(item.get("productName"));
                        pro.setProductNumber(item.get("productNumber"));
                        pro.setProductPrice(item.get("productPrice"));
                        mEntries.add(pro);
                    }

                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.d(TAG, databaseError.getMessage());
            }
        });
        return mEntries;
    }

    public static void addShoppingToFirebase(Shopping shopping) {
        mDatabase =  FirebaseDatabase.getInstance().getReference();
        shoppingCloudEndPoint = mDatabase.child("Shopping");
        String key = shoppingCloudEndPoint.push().getKey();
        shopping.setShoppingId(key);
        shoppingCloudEndPoint.child(key).setValue(shopping);
    }

    public static void deleteSelectedShoppingList(String shoppingId){
        mDatabase = FirebaseDatabase.getInstance().getReference();
        Query applesQuery = mDatabase.child("Shopping").orderByChild("shoppingId").equalTo(shoppingId);

        applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot questionSnapshot: dataSnapshot.getChildren()) {
                    questionSnapshot.getRef().removeValue();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "onCancelled", databaseError.toException());
            }
        });
    }

    public static void updateShoppingListById(Shopping shopping) {
        mDatabase = FirebaseDatabase.getInstance().getReference("Shopping");
        mDatabase.child(shopping.getShoppingId()).setValue(shopping);
    }



}
