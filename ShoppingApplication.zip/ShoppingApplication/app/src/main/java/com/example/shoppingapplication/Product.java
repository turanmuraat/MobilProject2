package com.example.shoppingapplication;

import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Product {
    static final String TAG = "Product";
    private String productId;
    private String productName;
    private String productPrice;
    private String productNumber;

    static DatabaseReference mDatabase;
    static DatabaseReference productCloudEndPoint;

    public Product(){

    }

    public Product(String productName, String productPrice, String productNumber) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.productNumber = productNumber;
    }

    public String getProductId() { return productId; }

    public void setProductId(String productId) { this.productId = productId; }

    public String getProductName() { return productName; }

    public void setProductName(String productName) { this.productName = productName; }

    public String getProductPrice() { return productPrice; }

    public void setProductPrice(String productPrice) { this.productPrice = productPrice; }

    public String getProductNumber() { return productNumber; }

    public void setProductNumber(String productNumber) { this.productNumber = productNumber; }

    public static List<Product> getProductList(String shoppingId){
        mDatabase =  FirebaseDatabase.getInstance().getReference();
        productCloudEndPoint = mDatabase.child("Shopping");
        List<Product> mEntries = new ArrayList<>();
        Query query = productCloudEndPoint.orderByChild("shoppingId").equalTo(shoppingId);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot noteSnapshot: dataSnapshot.getChildren()){
                    Shopping note = noteSnapshot.getValue(Shopping.class);
                    String temp = note.toString();
                    Log.d("note: ", temp + "\n"); // can log all
                    mEntries.add(note.getProduct());
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.d(TAG, databaseError.getMessage());
            }
        });
        return mEntries;
    }


    public static void addProductToFirebase(Product product) {
        mDatabase =  FirebaseDatabase.getInstance().getReference();
        productCloudEndPoint = mDatabase.child("Product");
        String key = productCloudEndPoint.push().getKey();
        product.setProductId(key);
        productCloudEndPoint.child(key).setValue(product);
    }

    public static void deleteSelectedProductList(String productId){
        mDatabase = FirebaseDatabase.getInstance().getReference();
        Query applesQuery = mDatabase.child("Product").orderByChild("productId").equalTo(productId);

        applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot questionSnapshot: dataSnapshot.getChildren()) {
                    questionSnapshot.getRef().removeValue();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "onCancelled", databaseError.toException());
            }
        });
    }

    public static void updateProductListById(Product product) {
        mDatabase = FirebaseDatabase.getInstance().getReference("Product");
        mDatabase.child(product.getProductId()).setValue(product);
    }
}



